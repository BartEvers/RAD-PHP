<p>Thank you for registering on the <?php e($title) ?> web site</p>

<p>Below you will find your activation code and a link that you can use to activate your membership for <?php e($title) ?>. Then, you will be able to log in and begin using the site.</p>

<p><?php echo $code ?></p>

<p><a href="<?php echo $link ?>"><?php echo $link ?></a></p>